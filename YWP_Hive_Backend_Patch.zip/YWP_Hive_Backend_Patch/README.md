# YWP OS — Hive Learning Backend Patch

Purpose: add a shared, privacy-preserving evidence bank so completed YWP decisions can improve future decisions across users without merging private user histories.

This patch is intentionally additive. Cursor should merge it into the CURRENT repository rather than replacing existing `learning.py`, `Result`, `ModelWeight`, settlement, auth, or decision-board logic.

## Core rule

**Every use makes us better** means:

1. YWP records the prediction that existed BEFORE an event.
2. A user's action (accepted / rejected / ignored) may be recorded as behavioral metadata.
3. A verified outcome resolves the prediction.
4. Only eligible, unique, pre-event predictions enter Hive training.
5. Hive outcomes update aggregate evidence and calibration.
6. Crowd popularity NEVER converts a bad pick into a good one. Verified outcomes are the learning truth.
7. The live decision engine can read a bounded Hive signal, but the Hive layer cannot silently manufacture probabilities.

## What this patch adds

- `HiveLearningEvent`: one sanitized prediction/outcome observation.
- `HiveAggregate`: smoothed aggregate results by sport / league / market / scope / model version.
- `HiveModelSnapshot`: versioned record of global Hive signal releases.
- API endpoints for recording predictions, resolving outcomes, querying a Hive signal, and reading aggregate stats.
- Deduplication/idempotency.
- Anonymous contributor key using HMAC; no name, email, device ID, stake or bankroll enters Hive.
- Training eligibility gates.
- Beta/Binomial smoothing to avoid overreacting to tiny samples.
- A bounded blend helper for the existing decision engine.
- PostgreSQL migration SQL.
- Tests.
- Integration instructions targeting the current YWP files/functions named in the v3.3.4 audit.

## Important integration rule

Do NOT delete or replace the current result-memory system.

The current backend already has:
- `backend/app/services/learning.py`
- `backend/app/models.py` with `Result` and `ModelWeight`
- `backend/app/api/sports.py`
- automatic board-result logging
- external sportsbook-result logging

The Hive consumes eligible results from those paths. Personal history and actual wager settlement remain separate.

## Environment variables

Add to Render:

```env
YWP_HIVE_ENABLED=true
YWP_HIVE_ANON_SECRET=<long random secret different from JWT secret>
YWP_HIVE_MIN_SAMPLE=40
YWP_HIVE_MAX_PROBABILITY_SHIFT=0.035
YWP_HIVE_REQUIRE_VERIFIED_OUTCOME=true
YWP_HIVE_REQUIRE_CONSENT=true
YWP_HIVE_RELEASE_VERSION=hive-1
```

`YWP_HIVE_REQUIRE_CONSENT=true` is deliberate. If the existing Terms/Privacy flow already gives valid consent for anonymized aggregate model improvement, Cursor may map that existing user preference/consent field into `consent_to_hive=True`. Do not silently invent consent.

## Database

Run `migration/001_hive_learning.sql` against the same PostgreSQL database used by the backend.

## Recommended order

1. Add the new files.
2. Run the migration.
3. Wire config.
4. Wire prediction capture after a recommendation is persisted.
5. Wire verified result resolution after the existing result is persisted/graded.
6. Add the read-only Hive signal call to the decision engine.
7. Run tests.
8. Deploy backend only after tests pass.
9. Verify `/api/v1/health` and then Hive diagnostics.
