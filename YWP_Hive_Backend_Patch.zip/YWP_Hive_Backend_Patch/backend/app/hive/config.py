from __future__ import annotations

import os
from dataclasses import dataclass


def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class HiveSettings:
    enabled: bool = _bool("YWP_HIVE_ENABLED", True)
    anon_secret: str = os.getenv("YWP_HIVE_ANON_SECRET", "")
    min_sample: int = int(os.getenv("YWP_HIVE_MIN_SAMPLE", "40"))
    max_probability_shift: float = float(
        os.getenv("YWP_HIVE_MAX_PROBABILITY_SHIFT", "0.035")
    )
    require_verified_outcome: bool = _bool(
        "YWP_HIVE_REQUIRE_VERIFIED_OUTCOME", True
    )
    require_consent: bool = _bool("YWP_HIVE_REQUIRE_CONSENT", True)
    release_version: str = os.getenv("YWP_HIVE_RELEASE_VERSION", "hive-1")


settings = HiveSettings()
