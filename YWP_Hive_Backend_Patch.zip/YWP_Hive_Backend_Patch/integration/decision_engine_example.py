# Example integration into the EXISTING YWP decision engine.
# Do not use this as a replacement model.

from app.hive.service import get_hive_signal, blend_hive_probability

signal = get_hive_signal(
    db=db,
    sport=candidate.sport,
    league=candidate.league,
    market=candidate.market,
    market_scope=candidate.market_scope,
    model_version=model_version,
)

hive_adjusted_probability, hive_meta = blend_hive_probability(
    base_probability=model_probability,
    hive_signal=signal,
)

# Keep both values.
candidate.model_probability = model_probability
candidate.hive_adjusted_probability = hive_adjusted_probability
candidate.hive_meta = hive_meta
