# Add immediately after the CURRENT graded result is successfully persisted.

from app.hive.service import resolve_hive_outcome

resolve_hive_outcome(
    db=db,
    source_recommendation_id=str(recommendation.id),
    outcome=result.outcome,              # WIN / LOSS / PUSH / VOID
    verified=result.is_verified,         # adapt to existing field
    result_source=result.source,         # adapt to existing field
    resolved_at=result.resolved_at,      # adapt to existing field
)
