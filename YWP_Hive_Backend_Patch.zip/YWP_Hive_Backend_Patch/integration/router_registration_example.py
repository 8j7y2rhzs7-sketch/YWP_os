# Example only. Adapt to the existing FastAPI application/router tree.

from app.hive.router import router as hive_router

# If the app already has /api/v1 at a parent router:
api_v1_router.include_router(hive_router)

# Or, if registering directly on FastAPI:
# app.include_router(hive_router, prefix="/api/v1")
