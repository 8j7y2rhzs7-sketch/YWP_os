# Cursor: apply this patch to the current YWP OS backend

Audit the repository first. Do not scaffold a new app and do not overwrite working v3.3.4 behavior.

## 1. Confirm the current objects

Locate:

- `backend/app/models.py`
  - `Result`
  - `ModelWeight`
  - recommendation model/table
  - user model/table
  - SQLAlchemy `Base` import location
- `backend/app/services/learning.py`
  - `performance`
  - `apply_micro_learning`
  - `load_feature_weights`
- `backend/app/api/sports.py`
  - analysis persistence
  - `_persist_graded_result`
  - `log_external`
- backend router registration
- backend settings/config object
- auth dependency for current user
- database session dependency

Preserve all of them.

## 2. Add the supplied files

Copy:

- `backend/app/hive/schemas.py`
- `backend/app/hive/models.py`
- `backend/app/hive/service.py`
- `backend/app/hive/router.py`
- `backend/app/hive/config.py`

If the repository's actual Base/session/settings import paths differ, adapt imports only; do not change behavior.

Register the router under `/api/v1/hive`.

## 3. Migration

Apply `migration/001_hive_learning.sql`.

If this project uses Alembic, translate the SQL into an Alembic revision while preserving the exact constraints/indexes.

## 4. Capture prediction snapshots

A Hive sample MUST originate from a persisted YWP recommendation that existed before the event.

After the current recommendation is saved, call:

```python
from app.hive.service import capture_hive_prediction

capture_hive_prediction(
    db=db,
    contributor_user_id=current_user.id,
    consent_to_hive=<existing user consent / privacy setting>,
    source_recommendation_id=str(recommendation.id),
    sport=recommendation.sport,
    league=recommendation.league,
    event_id=<official provider event id>,
    event_start_at=<official start datetime>,
    market=<canonical market type>,
    market_scope=<canonical settlement scope>,
    selection=<canonical selection>,
    line=<line or None>,
    odds_american=<actual price or None>,
    model_probability=<pre-event model probability or None>,
    quality_score=<YWP quality score or None>,
    model_version=<actual model version>,
    protocol_version=<actual protocol version>,
    evidence_version=<snapshot/provider evidence version>,
    data_quality=<0..1 completeness/reliability if already supported>,
    feature_flags=<small aggregate-safe dict of reason/check flags>,
)
```

Do NOT send:
- user name/email
- bankroll
- wager stake
- IP
- device identifiers
- free-form private notes

If model probability is unavailable/experimental, keep it `None`. Never derive it from YIS or quality score.

## 5. Resolve outcomes from the existing graded-result path

Inside or immediately after the existing `_persist_graded_result` succeeds:

```python
from app.hive.service import resolve_hive_outcome

resolve_hive_outcome(
    db=db,
    source_recommendation_id=str(recommendation.id),
    outcome=<WIN|LOSS|PUSH|VOID>,
    verified=<True only when result source is verified>,
    result_source=<official/provider/manual_verified/etc>,
    resolved_at=<timestamp>,
)
```

This is idempotent. Repeated provider sync must not train twice.

For `log_external`:
- preserve the external observation in personal/result memory;
- do NOT create a trainable Hive predictive sample unless it can be matched to an independent YWP prediction that existed before the event;
- a backfilled sportsbook result without a prior YWP prediction can be stored personally, but is not probability-calibration truth.

## 6. Record user choice separately

If the app already records whether a recommendation was selected, discarded, or ignored, call:

```python
record_hive_action(
    db=db,
    source_recommendation_id=str(recommendation.id),
    action="accepted" | "rejected" | "ignored",
)
```

This metadata may be used to understand product behavior, but must NOT change predictive truth by itself.

## 7. Use Hive signal in decision engine

Do not overwrite the existing model probability or quality score.

After the base model produces its probability, request:

```python
signal = get_hive_signal(
    db=db,
    sport=sport,
    league=league,
    market=market,
    market_scope=market_scope,
    model_version=model_version,
)
```

Then:

```python
adjusted_probability, hive_meta = blend_hive_probability(
    base_probability=base_probability,
    hive_signal=signal,
)
```

Rules:
- If base probability is `None`, return `None`; Hive cannot manufacture it.
- If Hive sample is below minimum, do not shift probability.
- Shift is bounded by `YWP_HIVE_MAX_PROBABILITY_SHIFT` (default ±3.5 percentage points).
- Persist/display base probability and Hive-adjusted probability as separate fields during validation.
- Do not claim calibration until enough eligible samples exist.

Suggested response fields:

```json
{
  "model_probability": 0.612,
  "hive_adjusted_probability": 0.626,
  "hive": {
    "eligible_samples": 418,
    "wins": 267,
    "losses": 151,
    "posterior_rate": 0.637,
    "shift_applied": 0.014,
    "release_version": "hive-1"
  }
}
```

## 8. Do not immediately reuse current problematic micro-learning behavior

The v3.3.4 audit found global weights could move from external results and that training populations were mixed. Keep the new Hive path gated and explicit.

Do not call `apply_micro_learning` from a raw Hive insert. If you later decide to update `ModelWeight`, do it from an audited Hive model release/snapshot, not every single row.

## 9. Required tests

Run existing backend tests plus the supplied tests.

Add integration tests proving:

1. Same recommendation/result cannot train twice.
2. Same public pick from many users creates many observations only when each came from a real pre-event YWP prediction, while exact retry of one user's observation remains idempotent.
3. No PII/stake is present in Hive rows.
4. `PUSH` and `VOID` do not count as wins/losses.
5. Unverified outcomes are not training eligible when required.
6. External backfill without prior YWP prediction is not training eligible.
7. Hive cannot create a probability when base model probability is `None`.
8. Probability adjustment is bounded.
9. Samples below minimum do not alter probability.
10. An aggregate rebuild from events reproduces the stored aggregate.

## 10. Completion report

Return:
- changed files
- migration name
- exact integration points
- tests run and actual results
- any import/path adaptations
- any blocked consent/auth mapping
- no invented deployment status

Do not deploy unless explicitly told to deploy.
