BEGIN;

CREATE TABLE IF NOT EXISTS hive_learning_events (
    id VARCHAR(36) PRIMARY KEY,
    idempotency_key VARCHAR(64) NOT NULL UNIQUE,
    contributor_key VARCHAR(64) NOT NULL,
    source_recommendation_id VARCHAR(128) NOT NULL,

    sport VARCHAR(32) NOT NULL,
    league VARCHAR(64),
    event_id VARCHAR(128) NOT NULL,
    event_start_at TIMESTAMPTZ,

    market VARCHAR(64) NOT NULL,
    market_scope VARCHAR(96) NOT NULL,
    selection VARCHAR(256) NOT NULL,
    line DOUBLE PRECISION,
    odds_american INTEGER,

    model_probability DOUBLE PRECISION,
    quality_score DOUBLE PRECISION,
    model_version VARCHAR(64) NOT NULL,
    protocol_version VARCHAR(64),
    evidence_version VARCHAR(128),
    data_quality DOUBLE PRECISION,
    feature_flags JSONB NOT NULL DEFAULT '{}'::jsonb,

    action VARCHAR(16),
    outcome VARCHAR(8),
    outcome_verified BOOLEAN NOT NULL DEFAULT FALSE,
    result_source VARCHAR(64),
    resolved_at TIMESTAMPTZ,

    consent_to_hive BOOLEAN NOT NULL DEFAULT FALSE,
    training_eligible BOOLEAN NOT NULL DEFAULT FALSE,
    training_ineligibility_reason VARCHAR(96),

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT ck_hive_probability
        CHECK (model_probability IS NULL OR (model_probability >= 0 AND model_probability <= 1)),
    CONSTRAINT ck_hive_quality
        CHECK (quality_score IS NULL OR (quality_score >= 0 AND quality_score <= 100)),
    CONSTRAINT ck_hive_data_quality
        CHECK (data_quality IS NULL OR (data_quality >= 0 AND data_quality <= 1)),
    CONSTRAINT ck_hive_action
        CHECK (action IS NULL OR action IN ('accepted','rejected','ignored')),
    CONSTRAINT ck_hive_outcome
        CHECK (outcome IS NULL OR outcome IN ('WIN','LOSS','PUSH','VOID'))
);

CREATE INDEX IF NOT EXISTS ix_hive_learning_events_contributor
    ON hive_learning_events (contributor_key);

CREATE INDEX IF NOT EXISTS ix_hive_learning_events_recommendation
    ON hive_learning_events (source_recommendation_id);

CREATE INDEX IF NOT EXISTS ix_hive_learning_events_event
    ON hive_learning_events (event_id);

CREATE INDEX IF NOT EXISTS ix_hive_learning_events_training
    ON hive_learning_events (training_eligible);

CREATE INDEX IF NOT EXISTS ix_hive_event_bucket
    ON hive_learning_events
    (sport, league, market, market_scope, model_version, training_eligible);


CREATE TABLE IF NOT EXISTS hive_aggregates (
    id VARCHAR(36) PRIMARY KEY,
    bucket_key VARCHAR(64) NOT NULL UNIQUE,

    sport VARCHAR(32) NOT NULL,
    league VARCHAR(64),
    market VARCHAR(64) NOT NULL,
    market_scope VARCHAR(96) NOT NULL,
    model_version VARCHAR(64) NOT NULL,

    eligible_samples INTEGER NOT NULL DEFAULT 0,
    wins INTEGER NOT NULL DEFAULT 0,
    losses INTEGER NOT NULL DEFAULT 0,
    pushes INTEGER NOT NULL DEFAULT 0,
    voids INTEGER NOT NULL DEFAULT 0,

    sum_predicted_probability DOUBLE PRECISION NOT NULL DEFAULT 0,
    predicted_probability_count INTEGER NOT NULL DEFAULT 0,

    raw_rate DOUBLE PRECISION,
    posterior_rate DOUBLE PRECISION,
    mean_predicted_probability DOUBLE PRECISION,
    calibration_delta DOUBLE PRECISION,

    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_hive_aggregate_lookup
    ON hive_aggregates
    (sport, league, market, market_scope, model_version);


CREATE TABLE IF NOT EXISTS hive_model_snapshots (
    id VARCHAR(36) PRIMARY KEY,
    release_version VARCHAR(64) NOT NULL,
    snapshot_type VARCHAR(32) NOT NULL DEFAULT 'aggregate_release',
    parameters JSONB NOT NULL DEFAULT '{}'::jsonb,
    sample_count INTEGER NOT NULL DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_hive_snapshot_release_type
        UNIQUE (release_version, snapshot_type)
);

COMMIT;
