from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from app.hive.service import (
    HiveSignal,
    blend_hive_probability,
    capture_hive_prediction,
    resolve_hive_outcome,
)


def _capture(db, *, recommendation_id="r1", probability=0.60, consent=True):
    now = datetime.now(timezone.utc)
    return capture_hive_prediction(
        db=db,
        contributor_user_id="user-123",
        consent_to_hive=consent,
        source_recommendation_id=recommendation_id,
        sport="mlb",
        league="MLB",
        event_id="game-123",
        event_start_at=now + timedelta(hours=3),
        market="moneyline",
        market_scope="full_game",
        selection="TEAM_A",
        line=None,
        odds_american=-120,
        model_probability=probability,
        quality_score=84.0,
        model_version="3.3.4",
        protocol_version="ywp-current",
        evidence_version="snapshot-1",
        data_quality=0.95,
        feature_flags={
            "l5_support": True,
            "lineup_verified": True,
            "private_note": "MUST NOT BE STORED",
        },
    )


def test_prediction_capture_is_idempotent(db_session, monkeypatch):
    monkeypatch.setenv("YWP_HIVE_ANON_SECRET", "test-secret")
    # If settings are loaded at import time in this repo, configure test env before import
    # or patch app.hive.config.settings for the fixture.

    a = _capture(db_session)
    db_session.flush()
    b = _capture(db_session)
    assert a.id == b.id


def test_feature_flags_are_allowlisted(db_session):
    event = _capture(db_session)
    assert "l5_support" in event.feature_flags
    assert "private_note" not in event.feature_flags


def test_verified_outcome_becomes_eligible(db_session):
    event = _capture(db_session)
    db_session.flush()

    resolved = resolve_hive_outcome(
        db=db_session,
        source_recommendation_id=event.source_recommendation_id,
        outcome="WIN",
        verified=True,
        result_source="official",
    )
    assert resolved.outcome == "WIN"
    assert resolved.training_eligible is True


def test_unverified_outcome_not_eligible_when_required(db_session):
    event = _capture(db_session, recommendation_id="r-unverified")
    db_session.flush()

    resolved = resolve_hive_outcome(
        db=db_session,
        source_recommendation_id=event.source_recommendation_id,
        outcome="WIN",
        verified=False,
        result_source="manual",
    )
    assert resolved.training_eligible is False


def test_hive_never_manufactures_probability():
    signal = HiveSignal(
        sport="mlb",
        league="mlb",
        market="moneyline",
        market_scope="full_game",
        model_version="3.3.4",
        eligible_samples=1000,
        wins=700,
        losses=300,
        pushes=0,
        voids=0,
        posterior_rate=0.699,
        raw_rate=0.70,
        mean_predicted_probability=0.61,
        calibration_delta=0.089,
        release_version="hive-1",
    )
    adjusted, meta = blend_hive_probability(
        base_probability=None,
        hive_signal=signal,
    )
    assert adjusted is None
    assert meta["used"] is False


def test_hive_shift_is_bounded():
    signal = HiveSignal(
        sport="mlb",
        league="mlb",
        market="moneyline",
        market_scope="full_game",
        model_version="3.3.4",
        eligible_samples=1000,
        wins=900,
        losses=100,
        pushes=0,
        voids=0,
        posterior_rate=0.899,
        raw_rate=0.90,
        mean_predicted_probability=0.50,
        calibration_delta=0.399,
        release_version="hive-1",
    )
    adjusted, meta = blend_hive_probability(
        base_probability=0.60,
        hive_signal=signal,
    )
    assert adjusted is not None
    assert adjusted >= 0.60
    assert meta["used"] is True
    assert abs(adjusted - 0.60) <= 0.03500001
