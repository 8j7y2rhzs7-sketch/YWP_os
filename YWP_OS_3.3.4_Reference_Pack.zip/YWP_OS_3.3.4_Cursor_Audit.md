# YWP OS 3.3.4 — app audit and Cursor implementation brief

Audit date: September 4, 2026 UTC. Prepared for GHOSTT YWP. Latest release checked: 3.3.4, published at 03:54:35 UTC; live health rechecked at 04:03:43 UTC.

The app has a substantial working foundation and several of the earlier Decision Board corrections are present. The next release should concentrate on settlement accounting, slate identity, truthful verification, and session reliability before expanding the visual effects or sport coverage. The original brand artwork and boot animation were recovered; they do not need to be guessed or replaced with invented designs.

## 1. What was actually checked

| Check | Result and limit |
| --- | --- |
| Prior requirements | Searched available conversation memory and stored YWP files; read the September 3 Decision Board instructions, earlier specification material, current repository rules and brand documentation. |
| Source | Inspected `android-v3.3.4` at `ffc46524dc1d8f61c797daf931fd1a34dc86bb22`. Earlier comparison baselines: 3.3.3 at `322bbd1fee2a0552bb627c885d8ace29dde0ba35` and backend `65ac95128bad4403c9574a7803290d805d17d2a8`. |
| Android artifact | Downloaded the actual 3.3.3 and 3.3.4 APK assets. The 3.3.4 asset is 118,443,620 bytes; archive identity and contents are documented in the evidence pack. It was not launched on an Android device. |
| Existing 3.3.4 backend tests | **81 passed**, zero failures/errors. These include authenticated API workflows using isolated test data. The earlier 3.3.3 suite also passed all 79 tests. |
| Intermediate backend settlement tests | **6 passed**, zero failures/errors; the later full 3.3.4 run includes the settlement checks. |
| Mobile TypeScript | `npm run typecheck` passed on both 3.3.3 and 3.3.4. |
| Mobile web export | The 3.3.3 export completed. The 3.3.4 attempt generated static routes, but a clean completed export was not reliably confirmed; rerun that gate in Cursor. Native rendering remains unverified. |
| Focused audit regressions | Three correctness assertions and one learning-setting contract assertion fail on **all three** inspected baselines, including the new 3.3.4 release. Actual outputs and runnable tests are in the evidence pack. |
| Live API | Public health returned version 3.3.4 on the final check, database OK, demo mode false. Provider health was degraded: MLB and odds probes connected; the ESPN NFL probe returned HTTP 403. |
| Graphics | Visually inspected the recovered original art and boot frames; inspected current components, assets, theme and export code. |
| Interactive UI / devices | **Blocked, not verified.** The supported browser preview failed to start; the Sites Preview Troubleshooting skill permits only two startup attempts, so further preview attempts stopped at that limit. No Android emulator or iPhone was available. I did not tap through the native APK, verify an exported PNG on a device, or perform a real-account login. |
| Private deployment settings | The supplied Render settings page was not accessible for inspection. Public health does not disclose the deployed commit, so the precise production branch/commit remains unverified. |

No production settings, accounts, bets, deployment, or repository branches were changed. Audit tests and temporary build output were created in isolated local checkouts.

Repository: [YWP_os](https://github.com/8j7y2rhzs7-sketch/YWP_os). Release: [android-v3.3.4](https://github.com/8j7y2rhzs7-sketch/YWP_os/releases/tag/android-v3.3.4).

3.3.4 APK SHA-256: `2762224b4194b2e9ea428566f5b8f172e6328181c0ec2232cd3abc5b33d2bbe5`.

The repository's `main` branch was older than the release when inspected. Cursor must check the actual working branch and installed/deployed versions before applying this report. Do not start from old `main` and accidentally remove today's updates. Release 3.3.4 includes the future-date settlement skip, version correction, removal of the demo-login shortcut, secret-protected tester provisioning, improved post-login routing and the custom-card Graphic Studio cache fix. Preserve these changes; the report does not classify the already-fixed custom-share opening bug as outstanding.

## 2. Requirements recovered from your existing work

These are recovered requirements, not new design inventions:

- Keep the original YWP crown/metallic black-and-gold identity, original reference graphics, strong display headings and readable factual text.
- Use the original art as visual reference only. Old players, odds, percentages and ticket selections in artwork must never become current analysis data.
- Keep YWP quality score, YIS, model win probability and data quality distinct. Unsupported probability stays unavailable. A quality score is not a percentage chance of winning.
- Keep one stable backend weakest-leg definition with its ID and explanation. Risk must reflect the actual card, leg count, uncertainty and dependencies.
- Identify both teams, market scope, line, price, bookmaker, event time/timezone and source freshness. Do not relabel another bookmaker's price as Hard Rock.
- Enforce the applicable current protocol: recent form/L5/L10, injuries, starters/lineups, matchup, workload, bullpen where relevant, weather/park where relevant, price, game script, cushion/Vision, AIN and the final check.
- Missing, stale, mismatched or unsupported evidence must remain PARTIAL/REVIEW/SKIP. No forced leg count and no synthetic production fallback.
- Preserve the current card families and A/B/C rules: A strongest eligible plays; B different players/theses; C best eligible combination from A and B.
- Preserve result memory, process grading, miss-by-one analysis and the new ability to log board picks or sportsbook picks that were never locked in the app.
- For soccer, distinguish 90-minute outcomes from qualification/extra-time markets. Do not pretend their settlement rules are interchangeable.

The current source explicitly describes immediate small learning updates and approval for larger updates. Older material emphasizes human approval. I could not recover a newer user instruction resolving the exact boundary. This report therefore preserves automatic result logging and asks Cursor to make the active learning policy explicit and consistent; it does not assume you wanted the new learning feature removed.

The September 3 Decision Board instructions are included unchanged in `requirements/` in the reference pack and are more specific than the older general blueprints.

## 3. What is already improved and should be preserved

- The production slate endpoint refuses to silently substitute demo data when live retrieval fails.
- Non-MLB research that lacks required evidence stays incomplete instead of being automatically called verified.
- The backend exposes quality/probability distinctions, outlier review, stable weakest-leg metadata, and disclosed joint-probability limitations.
- Current card construction retains the A/B/C structure and omits templates when too few eligible legs survive.
- The original crown and minimalist originals in the release match the recovered originals byte for byte.
- Custom ticket save feedback, ticket discard, score-sync feedback, board-result logging and external sportsbook-result logging are present. Version 3.3.4 also saves a custom card before opening its graphic and removes the demo-login shortcut.

These are useful improvements. Avoid replacing the app with a new scaffold or reapplying old patches wholesale.

## 4. Prioritized implementation tickets

P1 means fix before calling the next wider release reliable. P2 means usability, presentation or release-process work after the correctness fixes. A source finding is not presented as a device-observed failure.

### YWP-01 — P1 — Bind analysis to the slate actually loaded

**Confirmed by API reproduction and source.** Loading September 3 candidates, then submitting them with September 10 returns HTTP **201**. The app's date field changes immediately, but its sport-only loading effect does not reload the slate. `analyze()` sends the edited date alongside the old `slate.candidates`. A slow response can also overwrite a newer sport/date selection.

**Files:** `mobile/app/(tabs)/slate.tsx` (`loadSlate`, `analyze`, sport-only effect); `backend/app/schemas.py` (`SportsAnalyzeRequest`); `backend/app/api/sports.py` (`analyze`); `backend/app/services/live_generic_slate.py`.

The generic live builder also iterates the provider's returned upcoming events without filtering them to the requested slate date. Its missing/invalid start-time fallback invents 23:00 UTC. This is a separate source-confirmed route to wrong-date data.

**Implement:** Represent a loaded slate with sport, date, timezone, immutable snapshot ID and fetched-at time. Date/sport edits invalidate the loaded slate and disable analysis until a matching response arrives. Cancel or ignore superseded requests. Submit snapshot identity rather than trusting a client-supplied collection as verified evidence. Validate event/date/status on the server using a defined slate timezone and official event IDs; handle overnight events explicitly. Missing start time remains unknown and ineligible for verification.

**Acceptance:** Editing the date cannot analyze the old slate; rapid sport/date changes cannot display an older response; wrong-date inputs are rejected; midnight/timezone cases are correct; missing start time is not synthesized. `test_analyze_rejects_candidates_from_a_different_slate_date` must pass.

### YWP-02 — P1 — Separate ticket money from recommendation outcomes

**Confirmed by isolated settlement reproduction.** A $10 two-leg ticket with two +100 winners and a $40 return becomes `settled`, but performance reports **$0.00 profit and ROI unavailable**, rather than +$30.

**Files:** `backend/app/services/settlement.py` (`_settle_ticket`, `stake_per_leg`); `backend/app/models.py` (`Ticket`, `TicketLeg`, `Result`); `backend/app/services/learning.py` (`performance`).

The current code assigns zero stake to each leg of a multi-leg ticket and only sums recommendation-result P/L. There is no corresponding actual ticket settlement record in that path. A single `Result` per recommendation also cannot account correctly for the same pick appearing in multiple separately staked tickets. A pick graded earlier as an unbet board result can similarly retain zero monetary value when reused by a placed ticket.

**Implement:** Keep recommendation outcomes for research accuracy. Add an idempotent ticket settlement record for actual stake, accepted price/return, outcome, payout and net P/L, with linked bankroll ledger entries. Settle each ticket once after its active legs resolve. Support win/loss/push/void and explicit cash-out adjustments using the actual ticket terms; do not distribute parlay winnings arbitrarily among legs. Show separate totals for tracked predictions and actual wagers. Plan an auditable repair/backfill for affected existing tickets, preserving original records.

**Acceptance:** The reproduced ticket shows +$30; a losing $10 ticket shows -$10; all-void returns the stake with zero net P/L; mixed push/void follows recorded rules; repeated sync does not pay twice; the same recommendation on two tickets settles each ticket correctly; unbet board records never inflate money totals. `test_settled_two_leg_ticket_preserves_wager_profit` must pass.

### YWP-03 — P1 — Correct the non-MLB spread model before enabling it

**Confirmed by deterministic calculation.** With identical team form and the same selected team:

| Handicap | Current calculated probability |
| --- | ---: |
| -5.5, harder to cover | 58.6409% |
| 0 | 51.0784% |
| +5.5, easier to cover | 43.5159% |

**File:** `backend/app/services/sport_model.py`, `project_matchup`, spread adjustment. It subtracts `line / 40`, so a negative handicap increases the selected team's probability.

**Implement:** Fix the direction and add monotonicity checks for both sides. This correction alone does not validate the model: one linear adjustment and one totals scale are used across sports with very different scoring distributions. Keep experimental estimates labeled and ineligible where validation/evidence is missing. Build sport/market-specific margin and total models using verified samples; return unavailable when unsupported.

**Acceptance:** More favorable points never lower cover probability; changing side is consistent; no team-moneyline hit rate is passed off as a spread cover rate. The current incomplete-research gates must remain intact. `test_easier_spread_cannot_lower_cover_probability` must pass.

### YWP-04 — P1 — Give soccer explicit outcome and settlement semantics

**Confirmed in source; no live soccer ticket was placed.** The generic builder creates home/away moneylines and the shared model normalizes home plus away to 100%. It has no draw probability. The soccer button currently maps to MLS, while the backend also has separate EPL/MLS aliases. The shared market-label helper calls spreads/handicaps “Run line” without a sport parameter.

**Files:** `backend/app/services/live_generic_slate.py` (`SPORT_KEYS`, home/away loop); `backend/app/services/sport_model.py`; `backend/app/services/board_metrics.py` (`market_scope_label`); candidate/market schemas.

**Implement:** Model a market's outcome universe and settlement scope explicitly: 90-minute three-way, draw-no-bet, double chance, handicap, or to qualify. Include the draw where required, compare only matching bookmaker outcomes, and select the correct settlement rule. Do not infer extra-time coverage from “full game.” Name the selected league in the app. Make labels sport-aware: point spread, goal handicap or run line as appropriate.

**Acceptance:** A 90-minute draw is settled correctly for each supported market; a three-way market includes all three outcomes; unsupported scope is rejected/held for review; the UI never labels an NFL point spread as a run line. Preserve the existing strict-mode gates until these markets are actually supported.

### YWP-05 — P1 — Show provider readiness honestly and complete research by sport

**Live observation:** [Provider health](https://ywp-os-api.onrender.com/api/v1/health/providers) was degraded. The ESPN **NFL** scoreboard probe returned HTTP 403 while MLB and odds probes connected. This is a point-in-time finding, not proof that every ESPN endpoint or every sport is down. General [API health](https://ywp-os-api.onrender.com/api/v1/health) being OK does not mean all research is ready.

**Source findings:** `sport_research.py` deliberately leaves lineup/starter, motivation and sweep flags false. `readiness.py` treats an unknown bullpen source as a hard gap even outside baseball. Research currently fills fields such as average cushion `1.1`, script alignment `0.45`, role stability `0.45` and miss-by-one count `0`; its recent-hit-rate field can be team win percentage rather than the selected market's actual hit rate. Market consensus is labeled as verified market movement without a historical movement series.

**Files:** `backend/app/services/espn_provider.py` (`probe_espn_api`, `_get`); `backend/app/api/health.py`; `backend/app/services/readiness.py`; `backend/app/services/sport_research.py` (flags around lines 104–139 and candidate fields around lines 275–296); `mobile/app/(tabs)/index.tsx`.

**Implement:** Diagnose the provider response from the deployed environment and use supported source access or another verified provider where necessary. Keep failures visible and distinguish unavailable, out-of-season and incomplete research. Make required checks sport/market-specific and mark inapplicable checks N/A. Represent unavailable statistics as null/unknown, with source/time/sample size for real values. Separate price consensus from actual price movement. Display per-sport capability coverage; do not call a selectable sport fully supported merely because prices load. Remove the Command Center's unconditional `DOUBLE_CLEARED` badge and derive it from a particular completed run with current evidence.

**Acceptance:** A provider failure cannot leave the app globally “double cleared”; basketball is not blocked for a missing bullpen; unknown data is never represented by convincing constants; actual L5/L10 for the selected market is distinguishable from team form; missing lineups remain incomplete. Never fix this ticket by setting all verification flags to true.

### YWP-06 — P1 — Make exported graphics preserve evidence and status

**Confirmed in source; PNG/device output remains unverified.** `ShareCard` decides whether a card is official solely from whether it has legs. Nonempty cards say `OFFICIAL PLAYS`, the header says `FINAL PROTOCOL RERUN`, and the default control text says every leg cleared gates. The component does not receive analysis readiness, demo state, evidence expiry or a current lock result. Demo API flows can produce nonempty cards, so export needs its own truth-preserving state contract.

**Files:** `mobile/src/components/ShareCard.tsx` (around lines 13, 33, 56 and 114); `mobile/app/share-card.tsx`; export/card API types.

**Implement:** Pass immutable analysis/card evidence into export. Render explicit DEMO, RESEARCH INCOMPLETE, DRAFT, VERIFIED-AS-OF or EXPIRED states using the same rules as the board. An official/cleared claim must reference real current evidence; `FINAL PROTOCOL RERUN` requires an actual successful rerun. Include event names, exact market scope, bookmaker, price timestamp and score meaning. Rename ambiguous export `CONFIDENCE` to `YWP SCORE /100`; show model probability separately only when available. A generic button or footer must not grant verification.

**Acceptance:** A demo card is unmistakably demo; a stale saved build cannot export as currently verified; missing evidence remains visible; zero-leg PASS is accurate; original historical reference picks never appear as today's picks. Verify the exported image itself, not just the on-screen preview.

### YWP-07 — P1 — Scope cached analysis to the account and API environment

**Confirmed source design gap; account-switch/device reproduction is pending.** `AppDataContext` persists analyses/builds under global keys with no user/API scope or expiry. Logout clears auth but does not clear these caches. Analysis/share routes sit outside the tab authentication guard. Consumers do not wait for the cache's `ready` flag before declaring a card missing.

**Files:** `mobile/src/context/AppDataContext.tsx` (keys and hydration); `mobile/src/context/AuthContext.tsx` (`logout`); `mobile/app/_layout.tsx`; `mobile/app/analysis/[id].tsx`; `mobile/app/share-card.tsx`; `mobile/app/(tabs)/_layout.tsx`.

**Implement:** Namespace cached data by user ID, API environment and schema version. Clear the relevant in-memory data on account/environment changes and prevent an older hydration request from restoring it. Guard all private routes. Wait for hydration before deciding an item is unavailable. Add an authenticated server fetch for a saved analysis/build if persistent cross-device access is intended. Expired evidence may remain in history but must lose current official status.

**Acceptance:** Account B never renders account A's cached board; switching API environments cannot reuse a live verification badge; a deep link waits for auth and hydration; a valid saved card does not briefly report itself lost; old-schema records fail safely.

### YWP-08 — P1 — Prevent offline logout and concurrent refresh races

**Confirmed source failure paths; native reproduction pending.** During startup, any restore error reaches a catch that deletes saved tokens, including an offline/network failure. Parallel dashboard requests can each rotate the same refresh token; `rotate()` has no shared in-flight promise. `rawRequest()` has no request deadline.

**Files:** `mobile/src/context/AuthContext.tsx` (`rotate`, `request`, restoration effect); `mobile/src/lib/api.ts` (`rawRequest`); `mobile/app/(tabs)/index.tsx` (`Promise.all`).

**Implement:** Share one refresh operation per session and retry waiting requests with its result. Distinguish expired/revoked credentials from temporary connectivity failures. Retain the session on offline startup, render a retry state, and apply a bounded request timeout/cancellation path. Keep the server's single-use refresh protection.

**Acceptance:** Five simultaneous expired-token requests trigger one refresh; offline startup does not erase login; revoked credentials still require login; a stalled request exits its spinner and can be retried; logging out while refresh is pending cannot restore the old session.

### YWP-09 — P1 — Use the same backend metrics for custom cards

**Confirmed in source.** The custom-card preview recomputes risk as the worst single-leg risk and weakest leg using only quality/YIS. The backend's card functions also consider leg count, variance, miss-by-one, event concentration and stable tie-breaking. A custom two-leg card can therefore look low risk in preview when the backend's card rule says at least medium.

**Files:** `mobile/app/analysis/[id].tsx` (`customCard`, around lines 116–156); `backend/app/services/board_metrics.py` (`select_weakest_leg`, `card_risk`); ticket preview/create endpoints.

**Implement:** Request custom-card metrics from the backend using recommendation IDs and the current snapshot. Return the same card contract used by official cards. Remove the parallel frontend scoring implementation. Cache responses by the selected IDs and evidence version and ignore superseded responses.

**Acceptance:** Board preview, saved ticket, weakest-leg removal and exported card agree; selection reordering cannot change the weakest ID; ties include the backend criterion; a four-leg card receives the documented additional uncertainty treatment; unsupported joint probability remains unavailable.

### YWP-10 — P1 — Separate result memory, model learning and performance claims

**Reproduced configuration inconsistency:** With `learning_requires_human_approval=True`, logging one zero-stake external WIN activates a global `market_value` weight of **0.108** from the implicit 0.100 baseline. The function does not check that setting. The current Learning screen explains immediate micro-updates, while the Command Center still gives a broad human-approval assurance.

**Additional source findings:** Active weights are selected by sport/market/feature, not user. An external result has no prior independent model prediction, yet participates in immediate weight updates. Every external submission creates a new recommendation/result. Reanalyzed copies of one event can also become separate samples. Performance mixes tracked-board, external and wager results. “Confidence Calibration” bins quality score, rather than predicted probability, and its per-band denominator includes pushes/voids.

**Files:** `backend/app/services/learning.py` (`performance`, `apply_micro_learning` around line 438, `load_feature_weights`); `backend/app/api/sports.py` (`log_external`, `_persist_graded_result`); `backend/app/models.py` (`ModelWeight`, `Result`); `backend/app/core/config.py`; `mobile/app/(tabs)/learning.tsx`; `mobile/app/(tabs)/index.tsx`.

**Implement:** Preserve automatic outcome capture and book-result logging. Separate their storage from eligibility to train a production model. Store source, event/market/selection identity, prediction snapshot/version, result verification, user scope and deduplication/idempotency identifiers. Make the small-update versus approval-required policy explicit in configuration and UI. If immediate bounded micro-updates are intended, name the policy accordingly; do not leave a setting that appears to disable them while ignoring it. Shared production weights require an explicit shared-data policy and controlled eligible samples.

Keep quality-band outcome analysis, but label it as quality-band performance. Add real probability calibration separately using the model probability captured before the event, eligible unique samples, model/market versions and appropriate treatment of pushes/voids. Exclude external backfills with no prior model prediction from predictive calibration. Show tracked picks, external logs and actual wagers as separate selectable populations.

**Acceptance:** Resaving/retrying the same event observation does not train twice; unverified external backfills do not silently act as independent-model training truth; global versus personal learning is visible and intentional; the setting and UI agree; a quality score of 90 is not labeled a calibrated 90% win estimate. The fourth audit test captures the current configuration ambiguity: either honor the broad flag or explicitly split/rename the policy and update that test to the documented contract. Do not delete outcome memory to make it pass.

### YWP-11 — P2 — Finish the book-result entry workflow

**Confirmed in source.** The form always submits `sport: "mlb"`, `league: "MLB"` and today's **UTC** date. It has no slate-date selector. Version 3.3.4 has already removed the old Wacha/Quantrill help sentence; that copy fix is acknowledged. The date/sport limitations remain. In New York evening hours, the UTC date may already be tomorrow.

**File:** `mobile/app/log-result.tsx`, especially `todayIso`, payload around lines 62–64, and helper text around line 102.

**Implement:** Allow sport, league, event date/timezone, exact market scope, selection, actual outcome and bookmaker reference. Default the date using the user's timezone and let it be corrected. Prefill from an event lookup where possible. Treat old player names as placeholders only; remove time-sensitive personal copy from the released form. Add submission idempotency and an edit/correction audit trail. Keep monetary ticket results separate from research-only observations.

**Acceptance:** A WNBA result remains WNBA; a previous-day result retains that date; a New York evening entry is not assigned tomorrow; failed/retried saves do not duplicate learning; corrections preserve provenance.

### YWP-12 — P1 for failure recovery / P2 for design — Restore startup without creating a new trap

**Confirmed source path:** Root layout only reads the font loader's `loaded` value. A font error never hides the splash or reaches the app-level error boundary, because the component returns null before mounting it.

**Recovered design gap:** The current native splash uses the static crown. The recovered boot GIF and engine artwork are not imported in the release asset registry.

**Files:** `mobile/app/_layout.tsx`; `mobile/app.json`; `mobile/src/brandAssets.ts`; `mobile/src/components/LoadingState.tsx`; proposed `BootSequence` component.

**Implement:** Handle font success, error and a bounded fallback. Hide the native splash once a real fallback screen is ready. Add the original-inspired engine entrance described in section 5 as a separate, short app transition. It must never delay a ready session just to finish a timer. Derive loading labels from actual initialization states, with retry/offline actions when needed.

**Acceptance:** Font failure still produces a usable branded screen; offline startup is recoverable; reduced-motion users bypass animation; returning from background does not replay a long intro; boot labels do not claim research was verified before a protocol run.

### YWP-13 — P2 — Make the graphic layouts readable on real screens

**Source-based risks, not measured device failures:** The share graphic uses a fixed 4:5 box with `overflow: hidden`, small 7–12 point labels and no pagination in the component. Long selections, accessibility text scaling and a five-leg card can consume more height than expected. It maps all supplied legs even though the brand contract limits the template to five. Ambient animation loops run on every mounted screen without a reduced-motion check. The tab bar uses fixed height/bottom padding rather than explicitly accommodating device insets.

**Files:** `mobile/src/components/ShareCard.tsx`; `mobile/app/share-card.tsx`; `mobile/src/components/Screen.tsx`; `mobile/src/components/AmbientField.tsx`; `mobile/src/components/LoadingState.tsx`; `mobile/app/(tabs)/_layout.tsx`; `mobile/src/theme.ts`; `docs/BRAND_SYSTEM.md`.

**Implement:** Separate a predictable export canvas from the responsive phone preview; paginate over five legs and handle long text without clipping. Verify actual output is 1080×1350 and crisp before changing pixel-ratio code. Use the existing Syne/DM Sans system consistently. Keep display type for headings and clear body type for prices/statistics. Respect reduced motion, screen focus and app backgrounding. Use measured safe-area insets for bottom navigation. Bring brand documentation into agreement with current theme tokens rather than reverting the new palette automatically.

**Acceptance:** Inspect one-, three- and five-leg exports, long names, PASS/PARTIAL/DEMO states, large text and small iPhone widths. No clipped footer or concealed warnings. Tap targets meet the existing 44-logical-pixel brand requirement; statuses remain understandable without color. Verify on Android and iPhone before calling this visual polish complete.

### YWP-14 — P2 — Make releases identifiable and prepare store builds deliberately

**Confirmed:** App version is 3.3.4 / Android version code 14. The release backend settings and live health now also say 3.3.4; backend package metadata still uses 3.2.8. Public health has no commit identifier. The checked-in Gradle release configuration uses the debug signing configuration. The downloaded APK contains arm64, armeabi-v7a, x86 and x86_64 and is approximately 118 MB. None of this proves the iOS build has been tested.

**Files:** `mobile/app.json`; `mobile/android/app/build.gradle`; `mobile/eas.json`; `backend/app/core/config.py`; `backend/pyproject.toml`; `backend/app/api/health.py`; release workflow and build documentation.

**Implement:** Generate version, build number and commit metadata from the release process. Expose safe app/API/model/protocol/schema identifiers in a diagnostics screen and health response. Keep signing identity stable for the existing test install path; set up a deliberate production signing/distribution plan before a store release. Consider an Android App Bundle/store splits and a documented device-testing APK target rather than shipping all emulator ABIs to every phone. Resolve Expo native dependency compatibility warnings against the installed SDK before producing iOS/native release builds.

**Acceptance:** A screenshot of diagnostics uniquely identifies app and backend versions/commits; the installed APK matches its published artifact hash; release notes identify required backend changes; production credentials are not added to source; Android update continuity is tested; native dependency checks and an actual iOS build run successfully.

## 5. Recovered graphics and a faithful upgrade specification

The reference pack includes unchanged originals with a checksum manifest. The original names are recorded even where filenames were made easier for Cursor to handle.

| Recovered original | Actual file characteristics | Recommended role |
| --- | --- | --- |
| Metallic YWP OS Crown Emblem | 1254×1254 PNG; gold crown, circular crest, black background | Keep as primary native icon/splash/header identity. It already exists in the app. |
| YWP os Minimalist Logo | 1254×1254 PNG; dark mark on a white field | Keep for light/monochrome documents and partner surfaces. Do not put its white square into the dark header accidentally. |
| Metallic YWP OS Steampunk Control Banner | 1536×1024 PNG; crown, split mechanical/electronic brain, gold circuitry and control labels | Restore the engine/control-room identity in the welcome or Command Center hero, with a quiet area for real UI text. |
| Metallic YWP Decision Engine Poster | 853×1844 PNG; tall mechanical decision-engine composition | Portrait welcome/brand reference; avoid stretching it behind dense live statistics. |
| `ywp_os_boot_sequence_animated.gif` | 720×576; 24 frames × 90 ms; 2.16 seconds per cycle | Exact recovered animation reference. It has green mechanical styling and baked-in progress/status text, including 87%; those are artwork, not actual runtime progress. |
| Current repository reference cards | MLB protocol/final, Ghostt, SGP PASS and team-total designs | Preserve as historical layout references. Never import their old picks into live data. |
| WNBA Cushion/Spider cards, YWP strategy guide and sports decision-card design | Three additional recovered original images with dense black/gold panels, player images, odds and explicit control blocks | References for card hierarchy and WNBA presentation. Their old sample statistics, hit rates and 8/9-leg layouts are historical artwork, not a reason to force long current tickets or override the newer five-leg export rule. |

**The following is a new implementation proposal grounded in those originals, not a claim that these exact behaviors were previously approved:**

1. **Native launch:** Keep the crown on near-black for an immediate, reliable native splash. Preserve the current identity and avoid stretched artwork.
2. **App entrance:** Use the recovered engine imagery/motif for a short transition after the app can render. Preserve the original green mechanical reference in the animation treatment while retaining black/gold for the main interface. Do not globally replace the app palette with neon green.
3. **Real progress:** Build status labels as live UI tied to fonts/session/cache/connectivity. Keep the original GIF untouched in the archive, but do not ship its baked-in 87% or completed system checks as if they were measurements. If clean animation layers are unavailable, use the static original engine artwork with real status text in a separate panel until a reviewed motion asset exists.
4. **Command Center:** Use one strong brand/engine hero, followed by real API status, selected slate date, last successful run, pending results and a clear Run Protocol action. Move detailed protocol evidence into expandable panels. Reduce repeated all-caps slogans competing with the main task.
5. **Decision Board:** Keep the new display/body font pairing. Put decision, exact selection, matchup/market, price/book/time and YWP score in a consistent hierarchy. Put a distinct model-probability field next to its evidence state. Use the supplied crown and existing icon system; do not invent another logo.
6. **Graphic Studio:** Keep black/gold framing and original crest, with one state badge and readable selections. Use the exact same card/evidence object as the board. Design PASS, DEMO, PARTIAL and EXPIRED variants as deliberately as PLAY. Keep history/reference art separate from export data.
7. **Motion/accessibility:** Animate entrance and state changes sparingly. Honor reduced motion, pause decorative loops when hidden, and preserve legibility at larger text settings. Actual device measurements decide spacing adjustments.

Recovered files are sufficient to start this work. No new logo or replacement artwork was generated during this audit. Layered/vector sources and an exact approved modern mobile boot storyboard were not recovered; do not describe a recreation as an original.

### Additional feature coverage to finish after the corrections

Expose a truthful sport/market capability matrix rather than adding more sport buttons. The current generic and WNBA feeds construct moneyline, spread and total candidates; they do not complete the broader player-prop workflow shown in the recovered WNBA art. MLB prop retrieval is disabled by default in repository configuration; the actual production flag was not inspected. Prioritize verified WNBA player props, the requested baseball F5/team-total/prop scopes, and explicit soccer league/scope selection only when their providers, evidence and settlement rules are implemented. Keep unsupported items visibly unavailable.

## 6. iPhone path for this app

The project already uses Expo/React Native and has an iOS bundle identifier (`com.ywpos.app`). There is no evidence that a rewrite is needed. There is also no evidence here that an iOS build has already passed.

After the correctness fixes, configure the existing project for EAS, verify native dependencies and public API environment settings, then create an iOS build with `eas build --platform ios`. Store-distributed builds require Apple signing/account setup. Use TestFlight to install and test the build on an actual iPhone. [Expo build documentation](https://docs.expo.dev/build/setup/), [Apple TestFlight](https://developer.apple.com/testflight/).

Verify splash/font fallback, login restoration, offline startup, tab/home-indicator spacing, keyboard coverage, larger text, deep links, ticket save/lock flows and native image sharing. Review the existing Whop access/checkout flow against the intended distribution method before submission. This audit did not evaluate App Store eligibility or submit anything to Apple.

## 7. Cursor work order and proof

Work in small reviewable changes, in this order:

1. Establish the correct branch and app/API build identity. Preserve the later backend settlement fixes and today's mobile improvements.
2. Fix slate binding, ticket-level monetary settlement, spread direction and soccer scope. Keep unsupported markets gated.
3. Fix evidence propagation into status badges/exports and complete provider/readiness semantics.
4. Fix session/cache isolation and startup recovery; unify custom-card metrics.
5. Make learning policy/data eligibility explicit and finish date/sport-aware result entry.
6. Integrate the recovered engine/boot design and verify graphic layouts and iPhone behavior.

The included `tests/test_audit_regressions.py` is designed to be copied into `backend/tests/` in the existing repository. It uses the repository's existing test fixtures and `test_settlement` helpers; it does not contact production. Run from `backend/` with the normal test environment:

```bash
uv run pytest tests/test_audit_regressions.py -q -s
uv run pytest
```

Run `npm run typecheck` and a web export from `mobile/`, plus targeted native checks for changes that affect native behavior. The audit's four failing assertions must be addressed as described above; do not cosmetically alter the numbers or remove protections to obtain green tests.

Before calling the next release complete, attach:

- Exact source commits, artifact version/hash and deployed API identity.
- Passing targeted regressions and the existing relevant test/build results.
- A sanitized before/after API example for each data/settlement change.
- Actual device screenshots or recordings of startup, Command Center, date-switching slate, Decision Board, custom card, Ticket Vault, result logging, Learning and Graphic Studio.
- Actual exported PNGs for PLAY/PASS/DEMO/PARTIAL and long five-leg cases, plus an iPhone native-sharing check.
- An honest passed/failed/blocked checklist. Local tests alone do not prove the deployed app or installed APK was updated.

### Prompt to start the work in Cursor

> Audit the current YWP repository against this report and the included September 3 Decision Board requirements. Establish the active branch and compare it with android-v3.3.4 before editing. Preserve the included backend settlement fixes. Preserve the existing YWP identity, current card families, A/B/C logic, strict verification gates and new result-memory features. Implement the verified P1 corrections in small reviewable changes with the included reproductions and meaningful acceptance checks. Keep confirmed defects, source risks and device-unverified items distinct. Use the recovered original graphics; mark any new boot behavior as a proposal rather than remembered history. Never invent statistics, team identities, verification, probabilities, test results or deployment status. Produce changed files, migrations/backfill plan where needed, actual validation results and device evidence. Do not deploy, place bets or change production settings as part of this implementation report.

## 8. Evidence pack contents

- This report and `START_HERE.md`.
- Unchanged recovered original artwork/boot GIF and current original reference-card art.
- Recovered Decision Board instructions and earlier YWP specification chapters/blueprint.
- The four focused regression assertions and outputs from all three code baselines.
- Existing backend suite results, newer settlement test results, mobile typecheck and web export logs.
- Sanitized live-health observation, release identity and source/asset checksum manifest.
- Contact sheets of the actual recovered art/boot frames, explicitly reference material rather than app screenshots.

The pack intentionally contains no production credentials, private user records, environment values or raw provider-key diagnostics.
