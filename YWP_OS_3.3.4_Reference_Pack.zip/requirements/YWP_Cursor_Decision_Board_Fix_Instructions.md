# Cursor instructions: fix the YWP Decision Board

Audit and implement a targeted fix in the existing YWP app and backend. Preserve the current design, working integrations, and newest YWP protocol. Inspect existing patches before changing anything; do not reapply the previous fix without proving what remains broken. Do not place bets, expose credentials, or deploy without my approval.

## Screenshot reproduction case

The Core Parlay shows a large `91`, `MEDIUM`, and five legs:

| Displayed selection | YIS | Displayed percentage | American odds |
| --- | ---: | ---: | ---: |
| Cubs logo — Over 8.5 runs | 9.06 | 96% | -106 |
| Dodgers logo — Over 7.5 runs | 9.00 | 95% | -108 |
| Third logo — Over 8.5 runs | 8.37 | 89% | -103 |
| Texas Rangers ML | 8.18 | 88% | +105 |
| Miami Marlins -1.5 | 8.05 | 88% | +157 |

The screen names Texas Rangers ML as the weakest leg. The totals do not identify the opponent or market scope. Treat these as screenshot fixtures, not verified current picks. Do not invent the missing teams, dates, statistics, or event IDs.

## 1. Trace the actual running code

Trace each displayed value from data provider through backend scoring, card construction, JSON serialization, frontend mapping, and rendering. Identify the exact files/functions and formulas responsible. Inspect default values, percentage scaling, cached responses, demo fallbacks, duplicate scoring implementations, and the configured API base URL.

Check whether the earlier v3.1.0 fix exists in this checkout and whether the running backend and installed app actually contain it. Do not assume a prior patch was deployed. Separate confirmed root causes from hypotheses that require runtime access.

## 2. Separate score, probability, and data quality

Determine what `91`, `YIS`, and each displayed percentage currently mean. A screenshot alone does not prove that `91` is a win probability.

Use separate, clearly labeled fields for YWP quality score, model win probability, and data completeness/reliability. Document units and ranges in the API contract. Preserve a legitimate quality score, but display it as `YWP score: 91/100`, not an implied 91% chance of winning.

Never convert YIS, checklist completion, or confidence points directly into a win probability. Never silently replace missing values with plausible-looking numbers. Unsupported probability must be null/unavailable; it must not be fabricated or cosmetically capped. If the model is experimental or uncalibrated, expose that status and do not present its estimates as validated probabilities.

For this fixture, 0.96 × 0.95 × 0.89 × 0.88 × 0.88 = 0.628565, approximately 62.9%. That is ONLY a mathematical illustration if those inputs really are win probabilities and the legs are independent. It is not the ticket's verified chance. Do not multiply quality scores or use an average as parlay win probability. Handle shared-game/player dependence; without a supported joint estimate, show probability unavailable or a clearly labeled independence approximation, never false precision.

## 3. Correct weakest-leg and risk logic

Use one documented backend definition for the weakest leg and return its stable selection ID, criterion, and explanation. The frontend must render that returned result, not recompute it from list order or stale indexes.

If the criterion is lowest YIS, Miami is weakest in this fixture. If the criterion differs, show why Texas is selected. Equal rounded percentages do not prove equal underlying probabilities. Longer odds alone do not prove a model-ranking bug. Use deterministic tie-breaking and test filtering/reordering.

Calculate card risk from supported failure estimates, uncertainty, leg count, volatility, and dependencies as applicable. Do not use a fixed `MEDIUM` label or infer low risk from a high average quality score. Keep risk, quality, and value distinct.

## 4. Validate probabilities against the market without copying it

At +157, raw break-even probability is 100 / 257, about 38.9%. An 88% model estimate is a large discrepancy requiring investigation; the odds are not proof that the model must be wrong.

Add configurable, documented outlier checks that flag possible wrong events, reversed selections, game-total/team-total confusion, stale prices, percentage-scale errors, and model-calibration problems. Mark unresolved cases `REVIEW` and exclude them from official cards. Do not replace the model probability with the sportsbook implied probability or use arbitrary caps to conceal defects. Distinguish raw implied probability from a no-vig estimate, which needs matching outcome prices.

## 5. Enforce real-data and official-card gates

Keep the intended sources: official MLB data/MLB Stats API for baseball facts and the configured odds provider for prices. Show the actual bookmaker; never label another book's odds as Hard Rock. Real team names and demo mode being off are not sufficient verification.

Return event/selection IDs, source/provider, source and fetch timestamps where available, freshness state, model/protocol version, verification status, and missing-check reason codes. Keep secrets out of responses and logs.

Enforce the newest YWP required checks server-side, tailored to the market: correct event/date/status, market and price, starters/lineups, injuries, recent form, matchup, bullpen, weather/park, and other existing protocol requirements. Missing, stale, mismatched, or unsupported inputs must produce `REVIEW`, `RESEARCH INCOMPLETE`, or `SKIP`, with explicit reasons—not an official verified pick. Never force five legs. Test fixtures/demo data must never enter production official cards. Invalidate cached official status when its evidence expires or the event changes. Preserve the current A/B/C rules.

## 6. Make every displayed pick auditable

Display both teams, game date/time with timezone, selection, line, exact market scope (full-game total, team total, F5, moneyline, run line, etc.), bookmaker, odds timestamp, and verification status. Logos are decorative, not event identifiers. Details should expose the score meaning, evidence, missing checks, and weakest-leg explanation.

Keep the existing appearance and add the necessary labels/details. Make frontend and backend agree on nulls, field names, and schema versions. Handle older responses safely, without inventing defaults.

## 7. Tests and proof required before calling this fixed

- Add regression tests using the screenshot fixture, with unknown event details left unknown; incomplete fixtures must not pass official-card gates.
- Cover score/probability separation; 0–1 versus 0–100 scaling; null and non-finite values; odds conversion; the 62.9% independence illustration; unavailable probabilities; dependence handling; weakest-leg consistency and tie-breaking; risk logic; extreme model/market discrepancies; ambiguous markets; stale/missing/mismatched data; demo leakage; source labels; and safe cache/schema behavior.
- Test backend response to frontend rendering, including an older or incomplete response. Run the existing relevant tests, type checks, and available app build checks. Report actual commands and results; never claim a suite or live check passed if it was not run.
- Provide changed files, confirmed root cause(s), what differs from the previous patch, and a sanitized before/after API example. Clearly label mocked output versus a verified live response.
- Expose backend build/commit and model/schema versions through an appropriate diagnostic endpoint or existing health response. Show the app build/version and API environment in a diagnostics view. Do not expose secrets.
- Give the exact remaining Render deployment and Android rebuild/update steps based on the actual repository. If runtime credentials or deployment access are missing, state the blocker. Code changes and passing local tests do not prove the deployed app is fixed.

Implement and verify the correction, not just an explanation. Finish with a concise acceptance checklist showing passed, failed, and blocked items. Do not declare completion based only on changing the displayed numbers.
