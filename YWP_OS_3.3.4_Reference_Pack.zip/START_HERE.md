# YWP OS audit — start here

Open `YWP_OS_3.3.4_Cursor_Audit.md` in Cursor alongside the current YWP repository.
The report identifies the inspected release, confirmed defects, source-based risks,
recovered design requirements, proposed improvements, and checks still needing a device.

- `assets/originals/`: recovered artwork and the exact original boot GIF, unchanged.
- `assets/reference_cards/`: historical original card art already in the repository.
- `assets/original_asset_map.json`: original filenames, pack filenames and SHA-256 checksums.
- `visual_references/`: inspection contact sheets, **not screenshots of the running app**.
- `requirements/`: recovered specifications; the September 3 Decision Board instructions
  and current code take precedence over inconsistent older examples. Current brand docs
  contain older token values, as noted in the report.
- `tests/test_audit_regressions.py`: copy to the existing repository's `backend/tests/`.
  It imports the existing `test_settlement` helpers and uses the existing test database fixture.
- `evidence/`: actual outputs, sanitized live health and release identity. The existing
  3.3.4 suite passed 81 tests. The four audit assertions fail on all inspected baselines:
  three logic defects and a learning-setting contract discrepancy explained in YWP-10.

Older evidence without a 3.3.4 filename belongs to 3.3.3 or the intermediate backend;
`review_identity.json` and the report identify those baselines. Do not call an older
result proof of a newer build. Do not remove logging or weaken verification to make tests pass.

Do not treat old percentages, picks, player identities or success badges in art as live data.
The boot GIF includes baked-in 87%/status text; it is a reference, not a real progress meter.
No new logo was invented. The report clearly marks proposed boot behavior.

No production secrets, private account data, API-key diagnostics, full APKs or duplicate
legacy source archives are included. Use the pinned repository/tag for source. No deployment
or production changes were performed. Native UI/device verification remains outstanding.
