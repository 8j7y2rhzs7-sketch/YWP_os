# YWP verified-live engine fix

This package is based on the Cursor branch `cursor/deploy-backend-4fbe`.

## What this fixes

1. Real team names no longer imply that the research is complete.
2. Every slate and analysis is labeled `DEMO`, `PARTIAL`, or `VERIFIED`.
3. Sportsbook implied probability is identified as a market price, not an independent YWP projection.
4. Strict Mode blocks an official play when required YWP research is missing.
5. Production no longer silently falls back to synthetic records if a live provider fails.
6. The Android build no longer silently points to `localhost` in production.
7. The incorrect `official_pass_count` calculation is corrected.

## Files to copy into the Cursor repository

- `backend/app/services/readiness.py`
- `backend/app/services/decision_engine.py`
- `backend/app/services/live_mlb_slate.py`
- `backend/app/services/live_wnba_slate.py`
- `backend/app/services/live_generic_slate.py`
- `backend/app/services/providers.py`
- `backend/app/api/sports.py`
- `backend/app/schemas.py`
- `backend/tests/test_decision_engine.py`
- `mobile/src/lib/api.ts`
- `mobile/src/types.ts`
- `mobile/app/(tabs)/slate.tsx`
- `mobile/.env.production.example`
- `render.yaml`
- `backend/uv.lock`

Copy them with the same folder structure and commit them together because the API response and
mobile TypeScript types changed as one contract.

## Render settings

Set these in the deployed Render service, not inside the Android app:

```text
YWP_ENV=production
YWP_DEMO_MODE=false
ODDS_API_KEY=<real Odds API key>
DATABASE_URL=<Render PostgreSQL connection>
YWP_JWT_SECRET=<generated secret of at least 32 bytes>
```

Keep all provider keys private. Never use an `EXPO_PUBLIC_` name for a secret.

After committing the changes, redeploy the Render service and open:

```text
https://YOUR-RENDER-SERVICE.onrender.com/api/v1/health
```

Confirm that `demo_mode` is `false`.

## Android build setting

Set the following during the Expo/EAS production build:

```text
EXPO_PUBLIC_API_URL=https://YOUR-RENDER-SERVICE.onrender.com/api/v1
```

The public URL is safe in the app. Provider keys, JWT secrets, database credentials, and Whop
secrets are not.

## Correct meaning of the three statuses

- `DEMO`: synthetic records used only to test the interface.
- `PARTIAL`: real schedule or odds are present, but at least one required research input is missing.
  The engine may calculate diagnostics, but Strict Mode returns `SKIP`.
- `VERIFIED`: the independent probability and the complete YWP research checklist were supplied.
  Only this state is eligible for an official play.

## Validation

From `backend`:

```bash
uv sync --extra dev
uv run ruff check app tests migrations
uv run pytest
```

From `mobile`:

```bash
npm ci
npm run typecheck
npx expo-doctor@latest
```

The fix was verified against all 19 backend tests. Package installation for the mobile validation
requires normal npm network access.

